import React from 'react'
import Counter from './Pages/Counter/Counter'

const App = () => {
  return (
    <div>
      <center>
      <Counter/>
      </center>
    </div>
  )
}

export default App